class AssetsManager {
  static String imagePath = "assets/ImageNew";
  static String userImage = "$imagePath/person.png";
  static String botImage = "$imagePath/chat_logo.png";
  static String openaiLogo = "$imagePath/openai_logo.jpg";
}
