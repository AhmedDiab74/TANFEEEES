class Usuario {
  String username;
  String avatar;
  bool aovivo = false;

  Usuario({required this.username, required this.avatar});
}
