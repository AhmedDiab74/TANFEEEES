import 'dart:convert';
import 'package:wowondertimelineflutterapp/main.dart';
import 'package:wowondertimelineflutterapp/Util/AESEncryption/AES.dart';


performEncryption() {
  final data1 = json.decode(decrypted);
  accounts = data1["account"];
}
